package Dto;

import Dao.PersonDao;
import Dto.Person;
import java.sql.SQLException;
import java.util.ArrayList;

public class PersonDemo {

    public static void main(String[] args) throws SQLException {

        PersonDao personDao = new PersonDao();
        personDao.createPersonTable();        // create 'person' table in db.
        System.out.println("\nTable created successfully");

        // insert records to table
        System.out.println("Inserting records to table..");

        Person person1 = new Person("Tobias", "Jones", 25, 78945621L, 7894561237L);
        Person person2 = new Person("John", "Tanner", 28, 1234678L, 5318456784L);
        Person person3 = new Person("Luis", "Jimenez", 20, 1238978L, 535335984L);

        personDao.insertPerson(person1);
        personDao.insertPerson(person2);
        personDao.insertPerson(person3);

        // retrieve record from db

        System.out.println("Find 'John Tanner' from table ");

        Person person = personDao.selectPerson("John", "Tanner");
        if (person == null) {
            System.out.println("The record was not found.");
        } else {
            System.out.println("Record found.");
            System.out.println(person.toString());
        }

        // find everyone in table

        System.out.println("List all records in the table :");

        ArrayList<Person> allPeople = personDao.findAllPeople();
        if (allPeople.isEmpty()) {
            System.out.println("No record found");
        } else {
            System.out.println(allPeople.size() + " Records found");
            System.out.println(allPeople);
        }

        //deleting a record from table

        System.out.println("Delete 'Luis Jimenez' from table ");

        Person person4 = personDao.deletePerson("Jimenez", "Luis");
        if (person4 == null) {
            System.out.println("No such record found");
        } else {
            System.out.println("Deleted record : ");
            System.out.println(person4);
        }

        // list all people after deleting

        System.out.println("List after deletion of one record :");

        ArrayList<Person> peoples = personDao.findAllPeople();
        if (peoples.isEmpty()) {
            System.out.println("No record found");
        } else {
            System.out.println(peoples.size() + " Records found");
            System.out.println(peoples);
        }
    }
}