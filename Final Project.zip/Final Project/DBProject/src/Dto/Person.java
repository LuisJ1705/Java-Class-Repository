package Dto;
//person class which includes firstName, lastName, age, ssn and creditCard, it also gets the first name, last name, age, ssn and credit card for each person.
public class Person {

    private String firstName;
    private  String lastName;
    private  int age;
    private  long ssn;
    private long creditCard;

    public Person(String firstName, String lastName, int age, long ssn, long creditCard) {
        this.firstName = firstName;
        this.lastName = lastName;
        this.age = age;
        this.ssn = ssn;
        this.creditCard = creditCard;
    }

    public String getFirstName() {
        return firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public int getAge() {
        return age;
    }

    public long getSsn() {
        return ssn;
    }

    public long getCreditCard() {
        return creditCard;
    }

    @Override
    public String toString() {
        return "Person{" +
                "First Name = " + firstName + '\'' +
                ", Last Name = " + lastName + '\'' +
                ", Age = " + age +
                ", Social Security Number = " + ssn +
                ", Credit Card = " + creditCard +
                '}';
    }
}