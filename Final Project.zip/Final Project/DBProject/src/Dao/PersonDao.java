package Dao;
import Dto.Person;
import java.sql.*;
import java.util.ArrayList;

public class PersonDao {

    public void createPersonTable() throws SQLException {

        // create table query
        String sql = "CREATE TABLE IF IT DOESN'T EXIST person (\n" +
                "    id INT AUTO_INCREMENT,\n" +
                "    first_name VARCHAR(255) NOT NULL,\n" +
                "    last_name VARCHAR(255) NOT NULL,\n" +
                "    age TINYINT NOT NULL,\n" +
                "    ssn BIGINT NOT NULL,\n" +
                "    credit_card BIGINT,\n" +
                "    PRIMARY KEY (id)\n" +
                ")  ENGINE=INNODB;";

        Connection con = MysqlConnection.getConnection();
        Statement stmt = con.createStatement();
        stmt.executeUpdate(sql);
    }

    public void insertPerson(Person person) throws SQLException {

        String sql = "Insert data into person(firstName, lastName, age, ssn, creditCard) values(?,?,?,?,?)";  // query
        Connection con = MysqlConnection.getConnection();
        PreparedStatement pStatement = con.prepareStatement(sql);     // create a prepared statement
        pStatement.setString(1, person.getFirstName());
        pStatement.setString(2, person.getLastName());
        pStatement.setInt(3, person.getAge());
        pStatement.setLong(4, person.getSsn());
        pStatement.setLong(5, person.getCreditCard());

        pStatement.executeUpdate();       // execute query

        System.out.println("Record inserted successfully.");

    }

    public ArrayList<Person> findAllPeople() throws SQLException {

        String sql = "select * from person";

        Connection con = MysqlConnection.getConnection();
        Statement stmt = con.createStatement();
        ResultSet rs = stmt.executeQuery(sql);
        ArrayList<Person> persons = new ArrayList<>();

        while (rs.next()) {
            persons.add(new Person(rs.getString("firstName"),
                    rs.getString("lastName"),
                    rs.getInt("age"),
                    rs.getLong("ssn"),
                    rs.getLong("creditCard")));

        }

        return persons;
    }
    public Person selectPerson(String firstName, String lastName) throws SQLException {

        String sql = "select * person whose first name is = ? and last name is = ?";
        Connection con = MysqlConnection.getConnection();
        PreparedStatement pStatement = con.prepareStatement(sql);     // create a prepared statement
        pStatement.setString(1, firstName);
        pStatement.setString(2, lastName);
        ResultSet rs = pStatement.executeQuery();
        Person person = null;
        if (rs.next()) {
            person = new Person(rs.getString("firstName"),
                    rs.getString("lastName"),
                    rs.getInt("age"),
                    rs.getLong("ssn"),
                    rs.getLong("creditCard"));
        }
        return person;
    }
    public Person deletePerson(String firstName, String lastName) throws SQLException {

        Person person = selectPerson(firstName, lastName);
        //remove if person exists
        if (person != null) {
            String sql = "Delete person whose first name is = ? and last name is = ?";
            Connection con = MysqlConnection.getConnection();
            PreparedStatement pStatement = con.prepareStatement(sql);
            pStatement.setString(1, firstName);
            pStatement.setString(2, lastName);
            pStatement.execute(sql);
            System.out.println("Record deleted successfully.");
        }
        return person;
    }
}